import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

//
// ==========================
//        GET REPAIR
//  /api/repairs?deviceId=xxx
// ==========================
export async function GET(req) {
  try {
    const { searchParams } = new URL(req.url);
    const deviceId = searchParams.get("deviceId");

    if (!deviceId) {
      return NextResponse.json({ repair: null });
    }

    const repair = await prisma.repair.findFirst({
      where: { deviceId },
      include: { items: true },
    });

    return NextResponse.json({ repair: repair || null });
  } catch (e) {
    console.error("❌ REPAIR GET ERROR:", e);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

//
// ==========================
//        CREATE REPAIR
//          POST
// ==========================
export async function POST(req) {
  try {
    const body = await req.json();

    const newRepair = await prisma.repair.create({
      data: {
        deviceId: body.deviceId,
        status: body.status,
        diagnostic: body.diagnostic,
        notes: body.notes,
        items: {
          create: body.items.map((i) => ({
            kind: i.kind, // part / labor
            label: i.label,
            qty: i.qty,
            unitPrice: i.unitPrice,
          })),
        },
      },
      include: { items: true },
    });

    return NextResponse.json({ repair: newRepair });
  } catch (e) {
    console.error("❌ REPAIR POST ERROR:", e);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

//
// ==========================
//        UPDATE REPAIR
//           PUT
// ==========================
export async function PUT(req) {
  try {
    const body = await req.json();

    if (!body.id) {
      return NextResponse.json(
        { error: "ID reparație lipsă" },
        { status: 400 }
      );
    }

    // 1️⃣ ȘTERGEM toate piesele + manopera vechi
    await prisma.repairItem.deleteMany({
      where: { repairId: body.id },
    });

    // 2️⃣ ACTUALIZARE REPAIR
    const updatedRepair = await prisma.repair.update({
      where: { id: body.id },
      data: {
        status: body.status,
        diagnostic: body.diagnostic,
        notes: body.notes,
        items: {
          create: body.items.map((i) => ({
            kind: i.kind,
            label: i.label,
            qty: i.qty,
            unitPrice: i.unitPrice,
          })),
        },
      },
      include: { items: true },
    });

    return NextResponse.json({ repair: updatedRepair });
  } catch (e) {
    console.error("❌ REPAIR PUT ERROR:", e);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}