export const runtime = "nodejs"; // 👈 OBLIGATORIU

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

function isValidMongoId(id) {
  return /^[0-9a-fA-F]{24}$/.test(id);
}

export async function GET(request, { params }) {
  console.log("PARAMS =", params);

  const id = params?.id;

  if (!id) {
    return NextResponse.json({ error: "Lipsește ID-ul" }, { status: 400 });
  }

  if (!isValidMongoId(id)) {
    return NextResponse.json({ error: "ID invalid" }, { status: 400 });
  }

  try {
    const device = await prisma.device.findUnique({
      where: { id },
      include: {
        client: true,
        user: true,
        repairs: { include: { items: true } },
      },
    });

    if (!device) {
      return NextResponse.json(
        { error: "Device inexistent" },
        { status: 404 }
      );
    }

    return NextResponse.json(device);
  } catch (err) {
    console.error("❌ EROARE GET DEVICE:", err);
    return NextResponse.json(
      { error: "Eroare la citirea device-ului" },
      { status: 500 }
    );
  }
}