export default function ProtectedIndex() {
  return null;
}