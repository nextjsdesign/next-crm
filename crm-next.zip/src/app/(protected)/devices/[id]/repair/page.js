"use client";

import { useEffect, useState, useMemo } from "react";
import { useParams, useRouter } from "next/navigation";
import { toast } from "react-hot-toast";
import {
  User,
  Laptop2,
  Wrench,
  ClipboardList,
  CircleDollarSign,
  CheckCircle2,
  Loader2,
  ArrowLeft,
} from "lucide-react";

export default function DeviceRepairPage() {
  const params = useParams();
  const router = useRouter();
  const deviceId = params?.id;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [device, setDevice] = useState(null);
  const [existingRepair, setExistingRepair] = useState(null);

  // 🔧 form state
  const [status, setStatus] = useState("În lucru");
  const [diagnostic, setDiagnostic] = useState("");
  const [techNotes, setTechNotes] = useState("");

  const [parts, setParts] = useState([
    { label: "", qty: 1, price: "" }, // piese
  ]);
  const [labor, setLabor] = useState([
    { label: "", price: "" }, // manoperă
  ]);

  // ===== FETCH DEVICE + REPAIR =====
  useEffect(() => {
    if (!deviceId) return;

    const loadData = async () => {
      try {
        setLoading(true);

        // 🔹 1) Device info (vei face tu route /api/devices/[id])
        try {
          const resDevice = await fetch(`/api/devices/${deviceId}`);
          if (resDevice.ok) {
            const dev = await resDevice.json();
            setDevice(dev);
          } else {
            setDevice(null);
          }
        } catch (e) {
          setDevice(null);
        }

        // 🔹 2) Repair info (vei face tu /api/repairs?deviceId=...)
        try {
          const resRepair = await fetch(`/api/repairs?deviceId=${deviceId}`);
          if (resRepair.ok) {
            const data = await resRepair.json();
            if (data && data.repair) {
              const r = data.repair;
              setExistingRepair(r);

              setStatus(r.status || "În lucru");
              setDiagnostic(r.diagnostic || "");
              setTechNotes(r.notes || "");

              if (Array.isArray(r.items) && r.items.length > 0) {
                const partsItems = r.items.filter((it) => it.kind === "part");
                const laborItems = r.items.filter((it) => it.kind === "labor");

                setParts(
                  partsItems.length > 0
                    ? partsItems.map((it) => ({
                        label: it.label || "",
                        qty: it.qty || 1,
                        price: it.unitPrice?.toString() || "",
                      }))
                    : [{ label: "", qty: 1, price: "" }]
                );

                setLabor(
                  laborItems.length > 0
                    ? laborItems.map((it) => ({
                        label: it.label || "",
                        price: it.unitPrice?.toString() || "",
                      }))
                    : [{ label: "", price: "" }]
                );
              }
            }
          }
        } catch (e) {
          // ignorăm, înseamnă că nu există reparație încă
        }
      } catch (err) {
        console.error(err);
        toast.error("Eroare la încărcare fișă reparație.");
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [deviceId]);

  // ===== CALCUL SUME =====
  const { totalParts, totalLabor, total } = useMemo(() => {
    const partsSum = parts.reduce((sum, p) => {
      const qty = Number(p.qty) || 0;
      const price = Number(p.price) || 0;
      return sum + qty * price;
    }, 0);

    const laborSum = labor.reduce((sum, l) => {
      const price = Number(l.price) || 0;
      return sum + price;
    }, 0);

    return {
      totalParts: partsSum,
      totalLabor: laborSum,
      total: partsSum + laborSum,
    };
  }, [parts, labor]);

  // ===== HELPERS Piese / Manoperă =====
  const updatePart = (index, field, value) => {
    setParts((prev) =>
      prev.map((row, i) => (i === index ? { ...row, [field]: value } : row))
    );
  };

  const addPart = () => {
    setParts((prev) => [...prev, { label: "", qty: 1, price: "" }]);
  };

  const removePart = (index) => {
    setParts((prev) => (prev.length === 1 ? prev : prev.filter((_, i) => i !== index)));
  };

  const updateLabor = (index, field, value) => {
    setLabor((prev) =>
      prev.map((row, i) => (i === index ? { ...row, [field]: value } : row))
    );
  };

  const addLabor = () => {
    setLabor((prev) => [...prev, { label: "", price: "" }]);
  };

  const removeLabor = (index) => {
    setLabor((prev) => (prev.length === 1 ? prev : prev.filter((_, i) => i !== index)));
  };

  // ===== SUBMIT =====
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!deviceId) return;

    try {
      setSaving(true);

      const body = {
        id: existingRepair?.id || null,
        deviceId,
        status,
        diagnostic,
        notes: techNotes,
        items: [
          ...parts
            .filter((p) => p.label || p.price)
            .map((p) => ({
              kind: "part",
              label: p.label,
              qty: Number(p.qty) || 1,
              unitPrice: Number(p.price) || 0,
            })),
          ...labor
            .filter((l) => l.label || l.price)
            .map((l) => ({
              kind: "labor",
              label: l.label,
              qty: 1,
              unitPrice: Number(l.price) || 0,
            })),
        ],
      };

      const res = await fetch("/api/repairs", {
        method: existingRepair ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Eroare la salvare reparație.");

      toast.success("Fișa de reparație a fost salvată.");
      setExistingRepair(data.repair || null);
    } catch (err) {
      console.error(err);
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[70vh] text-gray-600 dark:text-gray-300">
        <Loader2 className="mr-2 w-5 h-5 animate-spin" />
        Se încarcă fișa de reparație...
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-4 sm:p-6 space-y-6">
      {/* HEADER + BACK */}
      <div className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => router.push("/devices")}
          className="inline-flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300 hover:text-blue-600"
        >
          <ArrowLeft className="w-4 h-4" />
          Înapoi la fișe service
        </button>

        <div className="flex items-center gap-2">
          <span className="text-xs uppercase tracking-wide text-gray-400">
            Status fișă reparație
          </span>
          <span
            className={`
              inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium
              ${
                status === "Finalizat"
                  ? "bg-green-100 text-green-700"
                  : status === "Refuzat"
                  ? "bg-red-100 text-red-700"
                  : "bg-blue-100 text-blue-700"
              }
            `}
          >
            <CheckCircle2 className="w-3 h-3" />
            {status}
          </span>
        </div>
      </div>

      {/* TITLU */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-gray-100">
          🛠️ Fișă de reparație
        </h1>
        {device && (
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Cod fișă:{" "}
            <span className="font-mono font-medium text-gray-800 dark:text-gray-200">
              {device.formCode || device.id}
            </span>
          </p>
        )}
      </div>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* STÂNGA – 2/3: Diagnostic, piese, manoperă */}
        <div className="lg:col-span-2 space-y-6">
          {/* CARD: Info client + device (read-only) */}
          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-sm p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="flex items-center gap-2 text-sm font-semibold text-gray-700 dark:text-gray-200">
                <ClipboardList className="w-4 h-4 text-blue-500" />
                Rezumat fișă service
              </h2>
            </div>

            {device ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                <div className="space-y-1">
                  <p className="text-gray-500 text-xs uppercase tracking-wide">
                    Client
                  </p>
                  <p className="font-medium text-gray-900 dark:text-gray-100 flex items-center gap-1">
                    <User className="w-4 h-4 text-blue-500" />
                    {device.client?.name || "—"}
                  </p>
                  <p className="text-gray-500">
                    {device.client?.phone || "—"}
                    {device.client?.email ? (
                      <>
                        {" · "}
                        {device.client.email}
                      </>
                    ) : null}
                  </p>
                </div>

                <div className="space-y-1">
                  <p className="text-gray-500 text-xs uppercase tracking-wide">
                    Dispozitiv
                  </p>
                  <p className="font-medium text-gray-900 dark:text-gray-100 flex items-center gap-1">
                    <Laptop2 className="w-4 h-4 text-blue-500" />
                    {device.deviceType || "—"} {device.brand} {device.model}
                  </p>
                  <p className="text-gray-500 text-xs">
                    SN / IMEI: {device.serialNumber || "—"}
                  </p>
                </div>
              </div>
            ) : (
              <p className="text-sm text-gray-500">
                Nu am putut încărca detaliile fișei. Poți continua totuși completarea
                reparației.
              </p>
            )}
          </div>

          {/* CARD: Diagnostic tehnician */}
          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-sm p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="flex items-center gap-2 text-sm font-semibold text-gray-700 dark:text-gray-200">
                <Wrench className="w-4 h-4 text-blue-500" />
                Diagnostic tehnician
              </h2>
            </div>

            <textarea
              value={diagnostic}
              onChange={(e) => setDiagnostic(e.target.value)}
              placeholder="Descrie clar defectul real, testele efectuate, cauza identificată..."
              className="input min-h-[90px] text-sm"
            />

            <textarea
              value={techNotes}
              onChange={(e) => setTechNotes(e.target.value)}
              placeholder="Note interne tehnician (ex: recomandări, observații, riscuri)..."
              className="input min-h-[70px] text-sm"
            />
          </div>

          {/* CARD: Piese folosite */}
          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-sm p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="flex items-center gap-2 text-sm font-semibold text-gray-700 dark:text-gray-200">
                <ClipboardList className="w-4 h-4 text-blue-500" />
                Piese utilizate
              </h2>
              <button
                type="button"
                onClick={addPart}
                className="text-xs px-3 py-1 rounded-full bg-blue-50 text-blue-700 hover:bg-blue-100"
              >
                + Adaugă piesă
              </button>
            </div>

            <div className="space-y-3">
              {parts.map((row, index) => (
                <div
                  key={index}
                  className="grid grid-cols-12 gap-2 items-center"
                >
                  <input
                    type="text"
                    value={row.label}
                    onChange={(e) => updatePart(index, "label", e.target.value)}
                    placeholder="Denumire piesă"
                    className="input text-xs py-2 col-span-7"
                  />
                  <input
                    type="number"
                    min="1"
                    value={row.qty}
                    onChange={(e) => updatePart(index, "qty", e.target.value)}
                    placeholder="Cant."
                    className="input text-xs py-2 text-center col-span-2"
                  />
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={row.price}
                    onChange={(e) => updatePart(index, "price", e.target.value)}
                    placeholder="Preț / buc"
                    className="input text-xs py-2 col-span-3"
                  />
                  {parts.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removePart(index)}
                      className="col-span-12 text-xs text-red-500 hover:text-red-600 text-right"
                    >
                      Șterge
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* CARD: Manoperă */}
          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-sm p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="flex items-center gap-2 text-sm font-semibold text-gray-700 dark:text-gray-200">
                <ClipboardList className="w-4 h-4 text-blue-500" />
                Manoperă
              </h2>
              <button
                type="button"
                onClick={addLabor}
                className="text-xs px-3 py-1 rounded-full bg-blue-50 text-blue-700 hover:bg-blue-100"
              >
                + Adaugă manoperă
              </button>
            </div>

            <div className="space-y-3">
              {labor.map((row, index) => (
                <div
                  key={index}
                  className="grid grid-cols-12 gap-2 items-center"
                >
                  <input
                    type="text"
                    value={row.label}
                    onChange={(e) => updateLabor(index, "label", e.target.value)}
                    placeholder="Tip intervenție (ex: înlocuire display, curățare, reballing...)"
                    className="input text-xs py-2 col-span-8"
                  />
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={row.price}
                    onChange={(e) => updateLabor(index, "price", e.target.value)}
                    placeholder="Preț manoperă"
                    className="input text-xs py-2 col-span-4"
                  />
                  {labor.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeLabor(index)}
                      className="col-span-12 text-xs text-red-500 hover:text-red-600 text-right"
                    >
                      Șterge
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* DREAPTA – 1/3: Summary + Status + Salvare */}
        <div className="lg:col-span-1 space-y-6">
          {/* CARD: Status + timeline simplu */}
          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-sm p-5 space-y-4">
            <h2 className="flex items-center gap-2 text-sm font-semibold text-gray-700 dark:text-gray-200">
              <Wrench className="w-4 h-4 text-blue-500" />
              Status lucrare
            </h2>

            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="input text-sm py-2.5"
            >
              <option value="În lucru">În lucru</option>
              <option value="În așteptare piese">În așteptare piese</option>
              <option value="Finalizat">Finalizat</option>
              <option value="Refuzat">Refuzat</option>
            </select>

            <div className="mt-3 space-y-2 text-xs text-gray-500 dark:text-gray-400">
              <p>Traseu recomandat:</p>
              <ol className="list-decimal list-inside space-y-1">
                <li>În lucru</li>
                <li>În așteptare piese (dacă e cazul)</li>
                <li>Finalizat</li>
                <li>Predat clientului (în fișa principală)</li>
              </ol>
            </div>
          </div>

          {/* CARD: Sumare costuri */}
          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-sm p-5 space-y-3">
            <h2 className="flex items-center gap-2 text-sm font-semibold text-gray-700 dark:text-gray-200">
              <CircleDollarSign className="w-4 h-4 text-green-500" />
              Costuri reparație
            </h2>

            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">Piese</span>
                <span className="font-medium text-gray-900 dark:text-gray-100">
                  {totalParts.toFixed(2)} lei
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Manoperă</span>
                <span className="font-medium text-gray-900 dark:text-gray-100">
                  {totalLabor.toFixed(2)} lei
                </span>
              </div>
              <div className="h-[1px] bg-gray-200 dark:bg-gray-700 my-2" />
              <div className="flex justify-between items-center">
                <span className="text-sm font-semibold text-gray-700 dark:text-gray-200">
                  Total
                </span>
                <span className="text-lg font-bold text-blue-600 dark:text-blue-400">
                  {total.toFixed(2)} lei
                </span>
              </div>
            </div>
          </div>

          {/* CARD: Salvare */}
          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-sm p-5 space-y-3">
            <h2 className="flex items-center gap-2 text-sm font-semibold text-gray-700 dark:text-gray-200">
              <CheckCircle2 className="w-4 h-4 text-blue-500" />
              Acțiuni
            </h2>

            <p className="text-xs text-gray-500 dark:text-gray-400">
              Când salvezi, fișa de reparație se leagă de fișa de service și poate fi
              folosită la print și istoric.
            </p>

            <button
              type="submit"
              disabled={saving}
              className="w-full inline-flex justify-center items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium py-2.5 rounded-xl disabled:opacity-60"
            >
              {saving && <Loader2 className="w-4 h-4 animate-spin" />}
              {saving ? "Se salvează..." : "💾 Salvează fișa de reparație"}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}